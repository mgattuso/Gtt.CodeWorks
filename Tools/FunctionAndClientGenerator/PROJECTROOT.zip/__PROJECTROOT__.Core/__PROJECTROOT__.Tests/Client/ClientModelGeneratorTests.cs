using System;
using System.Collections.Generic;
using System.Text;
using Gtt.CodeWorks;
using Gtt.CodeWorks.Duplicator;
using __PROJECTROOT__.CodeGen;
using Microsoft.CodeAnalysis;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace __PROJECTROOT__.Tests.Client
{
    [TestClass]
    public class ClientModelGeneratorTests
    {
        [TestMethod]
        public void CreateModels()
        {
            var c = new ClientGenerator("__CLIENTNAME__");
            c.Initialize(new GeneratorInitializationContext());
            var models = c.ModelDuplicator();
            Console.WriteLine(models);
        }
    }
}
